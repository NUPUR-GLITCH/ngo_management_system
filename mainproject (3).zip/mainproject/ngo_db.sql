-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2025 at 07:01 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ngo_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `badges`
--

CREATE TABLE `badges` (
  `id` int(11) NOT NULL,
  `volunteer_id` int(11) DEFAULT NULL,
  `badge_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `awarded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `certificates`
--

CREATE TABLE `certificates` (
  `id` int(11) NOT NULL,
  `volunteer_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL,
  `issued_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `certificate_layouts`
--

CREATE TABLE `certificate_layouts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `background_color` varchar(7) DEFAULT '#FFFFFF',
  `logo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `certificate_layouts`
--

INSERT INTO `certificate_layouts` (`id`, `title`, `description`, `background_color`, `logo`, `created_at`) VALUES
(9, 'xyz ', 'z', '#FFFFFF', 'logo_1751355452_WhatsApp Image 2025-06-29 at 8.53.19 AM.jpg', '2025-07-01 07:37:32');

-- --------------------------------------------------------

--
-- Table structure for table `contact_submissions`
--

CREATE TABLE `contact_submissions` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact_submissions`
--

INSERT INTO `contact_submissions` (`id`, `name`, `email`, `message`, `submitted_at`) VALUES
(5, 'kush', 'testuser@gmail.com', 'hloo', '2025-07-07 04:51:27'),
(6, 'kush', 'testuser@gmail.com', 'hloo', '2025-07-07 04:58:00'),
(7, 'kush', 'testuser@gmail.com', 'hlooo', '2025-07-07 05:02:15'),
(8, 'kush', 'testuser@gmail.com', 'hlooo', '2025-07-07 05:06:05');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `donor_name` varchar(255) NOT NULL,
  `feedback` text NOT NULL,
  `rating` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `starred` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `impact_portfolio`
--

CREATE TABLE `impact_portfolio` (
  `id` int(11) NOT NULL,
  `volunteer_id` int(11) NOT NULL,
  `hours` int(11) DEFAULT 0,
  `tasks_completed` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `learning_resources`
--

CREATE TABLE `learning_resources` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `url` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `duration` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `learning_resources`
--

INSERT INTO `learning_resources` (`id`, `title`, `category`, `url`, `description`, `duration`, `created_at`) VALUES
(146, 'Child Education Video 1', 'Child Education', 'https://www.youtube.com/watch?v=Eeh7itXHRSw', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(147, 'Child Education Video 2', 'Child Education', 'https://www.youtube.com/watch?v=FTs1ippXPOg', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(148, 'Child Education Video 3', 'Child Education', 'https://www.youtube.com/watch?v=lxNajYYGgxE', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(149, 'Child Education Video 4', 'Child Education', 'https://www.youtube.com/watch?v=5BIm0R1SRYk', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(150, 'Child Education Video 5', 'Child Education', 'https://www.youtube.com/watch?v=PYggwLltef0', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(151, 'Child Education Video 6', 'Child Education', 'https://www.youtube.com/watch?v=S1bAba7gvz0', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(152, 'Child Education Video 7', 'Child Education', 'https://www.youtube.com/watch?v=8KxwtJH6NSo', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(153, 'Child Education Video 8', 'Child Education', 'https://www.youtube.com/watch?v=IuS6Jg676hc', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(154, 'Child Education Video 9', 'Child Education', 'https://www.youtube.com/watch?v=vggioGcUkP8', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(155, 'Child Education Video 10', 'Child Education', 'https://www.youtube.com/watch?v=yGk52q3UP7U', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(156, 'Educational Channel 1', 'Child Education', 'https://www.youtube.com/channel/UCgZx0xpaMELR_YWpvwwWdEw', 'Educational channel for kids', NULL, '2025-07-02 05:03:09'),
(157, 'Educational Channel 2', 'Child Education', 'https://www.youtube.com/channel/UC7RCGWVd4j_WxIGalDkVi0w', 'Educational channel for kids', NULL, '2025-07-02 05:03:09'),
(158, 'YouTube Mod Resource', 'Child Education', 'https://www.youtube.com/mod', 'YouTube moderation resource', NULL, '2025-07-02 05:03:09'),
(159, 'Teens of God Channel', 'Child Education', 'https://www.youtube.com/@teensofgod07', 'Educational content for teens', NULL, '2025-07-02 05:03:09'),
(160, 'Educational Channel 3', 'Child Education', 'https://www.youtube.com/channel/UC2ri4rEb8abnNwXvTjg5ARw', 'Educational channel for kids', NULL, '2025-07-02 05:03:09'),
(161, 'Child Education Video 11', 'Child Education', 'https://www.youtube.com/watch?v=z7qIq5EsjuQ', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(162, 'Child Education Video 12', 'Child Education', 'https://www.youtube.com/watch?v=Zc83hu5Qvxk', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(163, 'Child Education Video 13', 'Child Education', 'https://www.youtube.com/watch?v=KxLF9f1U7Y8', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(164, 'Child Education Video 14', 'Child Education', 'https://www.youtube.com/watch?v=sCPREA5NFTU', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(165, 'Child Education Video 15', 'Child Education', 'https://www.youtube.com/watch?v=g-h-wEu2BD8', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(166, 'Child Education Video 16', 'Child Education', 'https://www.youtube.com/watch?v=TLVoarTaKZc', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(167, 'Educational Playlist', 'Child Education', 'https://www.youtube.com/playlist?list=PL4uGv9d4OTXEhfkgbCNgp-QWxW8s3QHLI', 'Playlist on child education', NULL, '2025-07-02 05:03:09'),
(168, 'Child Education Video 17', 'Child Education', 'https://www.youtube.com/watch?v=tYmvsrkN8po', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(169, 'Child Education Video 18', 'Child Education', 'https://www.youtube.com/watch?v=8eUyIXXMxF0', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(170, 'Child Education Video 19', 'Child Education', 'https://www.youtube.com/watch?v=3Dg9vYnkisE', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(171, 'Child Education Video 20', 'Child Education', 'https://www.youtube.com/watch?v=fEgwefwYTm0', 'Educational video on child learning', NULL, '2025-07-02 05:03:09'),
(172, 'Teaching Hope Article', 'Child Education', 'https://time.com/3395822/teaching-hope/', 'Article on teaching hope', NULL, '2025-07-02 05:03:09'),
(173, 'Educational Channels List', 'Child Education', 'https://www.lifewire.com/educational-youtube-channels-for-kids-11693841', 'List of educational channels', NULL, '2025-07-02 05:03:09'),
(174, 'FT Education Article', 'Child Education', 'https://www.ft.com/content/676d74d6-7485-4ac8-bc56-5ef8f47258a1', 'Financial Times education article', NULL, '2025-07-02 05:03:09'),
(175, 'Evidyaloka Resource', 'Child Education', 'https://www.evidyaloka.org/', 'Evidyaloka education platform', NULL, '2025-07-02 05:03:09'),
(176, 'MS Rachel News', 'Child Education', 'https://www.parents.com/ms-rachel-named-ambassador-for-save-the-children-7966428', 'News on child education ambassador', NULL, '2025-07-02 05:03:09'),
(177, 'Bachpan Bachao Andolan', 'Child Welfare', 'https://en.wikipedia.org/wiki/Bachpan_Bachao_Andolan', 'Wikipedia on child welfare NGO', NULL, '2025-07-02 05:03:09'),
(178, 'Evidyaloka Wiki', 'Child Education', 'https://en.wikipedia.org/wiki/EVidyaloka', 'Wikipedia on Evidyaloka', NULL, '2025-07-02 05:03:09'),
(179, 'Parikrma Humanity Foundation', 'Child Welfare', 'https://en.wikipedia.org/wiki/Parikrma_Humanity_Foundation', 'Wikipedia on Parikrma', NULL, '2025-07-02 05:03:09'),
(180, 'Katha NGO', 'Child Welfare', 'https://en.wikipedia.org/wiki/Katha_%28NGO%29', 'Wikipedia on Katha NGO', NULL, '2025-07-02 05:03:09'),
(181, 'Room to Read Channel', 'Child Education', 'https://www.youtube.com/user/RoomtoRead', 'Room to Read educational channel', NULL, '2025-07-02 05:03:09'),
(182, 'World Vision USA', 'Child Welfare', 'https://www.youtube.com/user/worldvisionusa', 'World Vision USA channel', NULL, '2025-07-02 05:03:09'),
(183, 'Pratham India', 'Child Education', 'https://www.youtube.com/user/PrathamIndia', 'Pratham India educational channel', NULL, '2025-07-02 05:03:09'),
(184, 'Teach For India', 'Child Education', 'https://www.youtube.com/user/TeachForIndia', 'Teach For India channel', NULL, '2025-07-02 05:03:09'),
(185, 'UNICEF Channel', 'Child Welfare', 'https://www.youtube.com/user/unicef', 'UNICEF educational channel', NULL, '2025-07-02 05:03:09'),
(186, 'Child Welfare Video 1', 'Child Welfare', 'https://www.youtube.com/watch?v=9vX3A_5lS0w', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(187, 'Child Welfare Video 2', 'Child Welfare', 'https://www.youtube.com/watch?v=5qL7g9m1J0Y', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(188, 'Child Welfare Video 3', 'Child Welfare', 'https://www.youtube.com/watch?v=3kJ7z5YkR0I', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(189, 'Child Welfare Video 4', 'Child Welfare', 'https://www.youtube.com/watch?v=4kR9k1f3b2Q', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(190, 'Child Welfare Video 5', 'Child Welfare', 'https://www.youtube.com/watch?v=8j9z5kX0r2A', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(191, 'Child Welfare Video 6', 'Child Welfare', 'https://www.youtube.com/watch?v=7qX9v1f8b3M', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(192, 'Child Welfare Video 7', 'Child Welfare', 'https://www.youtube.com/watch?v=c4j7CcxV6qE', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(193, 'Child Welfare Video 8', 'Child Welfare', 'https://www.youtube.com/watch?v=2rK9v3x5b7Y', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(194, 'Child Welfare Video 9', 'Child Welfare', 'https://www.youtube.com/watch?v=6y8z9w4kP1Q', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(195, 'Child Welfare Video 10', 'Child Welfare', 'https://www.youtube.com/watch?v=xA5rMY1cFgs', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(196, 'Child Welfare Video 11', 'Child Welfare', 'https://www.youtube.com/watch?v=9pQ2zX7m3R4', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(197, 'Child Welfare Video 12', 'Child Welfare', 'https://www.youtube.com/watch?v=3m9z5kX0r2A', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(198, 'Child Welfare Video 13', 'Child Welfare', 'https://www.youtube.com/watch?v=5tY7z9w4kP1Q', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(199, 'Child Welfare Video 14', 'Child Welfare', 'https://www.youtube.com/watch?v=7rQ2zX7m3R4', 'Video on child welfare', NULL, '2025-07-02 05:03:09'),
(200, 'Child Welfare Video 15', 'Child Welfare', 'https://www.youtube.com/watch?v=4j7CcxV6qE2', 'Video on child welfare', NULL, '2025-07-02 05:03:09');

-- --------------------------------------------------------

--
-- Table structure for table `redemptions`
--

CREATE TABLE `redemptions` (
  `id` int(11) NOT NULL,
  `volunteer_id` int(11) NOT NULL,
  `reward_id` int(11) NOT NULL,
  `redeemed_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rewards`
--

CREATE TABLE `rewards` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `points_required` int(11) NOT NULL,
  `type` enum('merchandise','certificate','event') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rewards`
--

INSERT INTO `rewards` (`id`, `name`, `description`, `points_required`, `type`) VALUES
(1, 'NGO T-Shirt', 'Official Space ECE T-Shirt', 200, 'merchandise'),
(2, 'Volunteer Certificate', 'E-Certificate of Appreciation', 150, 'certificate'),
(3, 'Donor Event Access', 'Exclusive access to donor event', 300, 'event');

-- --------------------------------------------------------

--
-- Table structure for table `stories`
--

CREATE TABLE `stories` (
  `id` int(11) NOT NULL,
  `volunteer_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `media_path` varchar(255) DEFAULT NULL,
  `media_type` enum('image','video') DEFAULT NULL,
  `media_file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stories`
--

INSERT INTO `stories` (`id`, `volunteer_id`, `title`, `content`, `created_at`, `media_path`, `media_type`, `media_file`) VALUES
(14, 17, 'my story', 'hlooo', '2025-07-07 05:11:42', NULL, NULL, '17_1751865102_Best NGOs for Children India.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `survey_submissions`
--

CREATE TABLE `survey_submissions` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `submission_date` datetime DEFAULT current_timestamp(),
  `feedback` text NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `survey_submissions`
--

INSERT INTO `survey_submissions` (`id`, `name`, `email`, `submission_date`, `feedback`, `submitted_at`) VALUES
(6, 'AKASH', 'test@example.com', '2025-07-07 10:19:20', 'great', '2025-07-07 04:49:20'),
(7, 'Nupur', 'testuser@gmail.com', '2025-07-07 10:21:48', 'good work', '2025-07-07 04:51:48'),
(8, 'kush', 'test@donor.com', '2025-07-07 10:28:18', 'good work', '2025-07-07 04:58:18'),
(9, 'Nupur', 'testuser@gmail.com', '2025-07-07 10:32:30', 'good', '2025-07-07 05:02:30'),
(10, 'Nupur', 'testuser@gmail.com', '2025-07-07 10:36:22', 'good', '2025-07-07 05:06:22');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `volunteer_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `required_skills` varchar(255) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `status` enum('open','assigned','completed') DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `volunteer_id`, `title`, `description`, `required_skills`, `type`, `status`, `created_at`) VALUES
(37, 17, 'Update contact lists in the database', 'xyz', 'english', 'Administrative Support', 'completed', '2025-07-07 05:10:17');

-- --------------------------------------------------------

--
-- Table structure for table `task_notifications`
--

CREATE TABLE `task_notifications` (
  `id` int(11) NOT NULL,
  `volunteer_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `video_progress`
--

CREATE TABLE `video_progress` (
  `id` int(11) NOT NULL,
  `volunteer_id` int(11) NOT NULL,
  `video_id` int(11) NOT NULL,
  `watched` tinyint(1) DEFAULT 0,
  `watched_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `video_progress`
--

INSERT INTO `video_progress` (`id`, `volunteer_id`, `video_id`, `watched`, `watched_at`) VALUES
(6, 8, 164, 1, '2025-07-07 03:58:54'),
(7, 8, 146, 1, '2025-07-07 03:59:00'),
(8, 8, 146, 1, '2025-07-07 04:08:45');

-- --------------------------------------------------------

--
-- Table structure for table `volunteers`
--

CREATE TABLE `volunteers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `skills` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `points` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `availability` varchar(255) DEFAULT NULL,
  `experience` text DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `volunteers`
--

INSERT INTO `volunteers` (`id`, `name`, `email`, `username`, `password`, `skills`, `location`, `points`, `created_at`, `availability`, `experience`, `profile_pic`) VALUES
(8, 'KUSH', 'test@example.com', 'KUSH', 'testpass', 'coding', 'India', 250, '2025-06-30 07:13:40', 'weekends', '1 year', '8_Asta Black Clover.jpg'),
(9, 'Nupur', 'testuser@gmail.com', 'NUPUR', 'testpass1', 'CODING', 'Haryana', 240, '2025-06-30 07:15:49', '10 hours', 'no', NULL),
(14, 'UTKARSH', 'testuser@gmail.com', 'UTKARSH', 'testpass2', 'CODING', 'up', 0, '2025-07-04 03:58:28', '9 hours', 'no', NULL),
(15, 'AKASH', 'testuser@gmail.com', 'AKASH', 'testpass', 'CODING', 'rajasthan', 0, '2025-07-07 04:50:20', '9 hours PER WEEK', '2 years', NULL),
(16, 'AKASH', 'test@donor.com', 'AKASH1', 'koko', 'CODING', 'haryana', 0, '2025-07-07 04:59:05', '6hours', 'no', '16_Asta Black Clover.jpg'),
(17, 'Nupur1', 'test@example.com', 'NUPUR1', 'koko', 'CODING', 'Haryana', 10, '2025-07-07 05:08:37', '6hours', 'no', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `badges`
--
ALTER TABLE `badges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `volunteer_id` (`volunteer_id`);

--
-- Indexes for table `certificates`
--
ALTER TABLE `certificates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `volunteer_id` (`volunteer_id`),
  ADD KEY `layout_id` (`layout_id`);

--
-- Indexes for table `certificate_layouts`
--
ALTER TABLE `certificate_layouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_submissions`
--
ALTER TABLE `contact_submissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `impact_portfolio`
--
ALTER TABLE `impact_portfolio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `volunteer_id` (`volunteer_id`);

--
-- Indexes for table `learning_resources`
--
ALTER TABLE `learning_resources`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `redemptions`
--
ALTER TABLE `redemptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `volunteer_id` (`volunteer_id`),
  ADD KEY `reward_id` (`reward_id`);

--
-- Indexes for table `rewards`
--
ALTER TABLE `rewards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stories`
--
ALTER TABLE `stories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `volunteer_id` (`volunteer_id`);

--
-- Indexes for table `survey_submissions`
--
ALTER TABLE `survey_submissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `volunteer_id` (`volunteer_id`);

--
-- Indexes for table `task_notifications`
--
ALTER TABLE `task_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `video_progress`
--
ALTER TABLE `video_progress`
  ADD PRIMARY KEY (`id`),
  ADD KEY `volunteer_id` (`volunteer_id`),
  ADD KEY `video_id` (`video_id`);

--
-- Indexes for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `badges`
--
ALTER TABLE `badges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `certificates`
--
ALTER TABLE `certificates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `certificate_layouts`
--
ALTER TABLE `certificate_layouts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `contact_submissions`
--
ALTER TABLE `contact_submissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `impact_portfolio`
--
ALTER TABLE `impact_portfolio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `learning_resources`
--
ALTER TABLE `learning_resources`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `redemptions`
--
ALTER TABLE `redemptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rewards`
--
ALTER TABLE `rewards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `stories`
--
ALTER TABLE `stories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `survey_submissions`
--
ALTER TABLE `survey_submissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `task_notifications`
--
ALTER TABLE `task_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `video_progress`
--
ALTER TABLE `video_progress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `volunteers`
--
ALTER TABLE `volunteers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `badges`
--
ALTER TABLE `badges`
  ADD CONSTRAINT `badges_ibfk_1` FOREIGN KEY (`volunteer_id`) REFERENCES `volunteers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `certificates`
--
ALTER TABLE `certificates`
  ADD CONSTRAINT `certificates_ibfk_1` FOREIGN KEY (`volunteer_id`) REFERENCES `volunteers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `certificates_ibfk_2` FOREIGN KEY (`layout_id`) REFERENCES `certificate_layouts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `impact_portfolio`
--
ALTER TABLE `impact_portfolio`
  ADD CONSTRAINT `impact_portfolio_ibfk_1` FOREIGN KEY (`volunteer_id`) REFERENCES `volunteers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `redemptions`
--
ALTER TABLE `redemptions`
  ADD CONSTRAINT `redemptions_ibfk_1` FOREIGN KEY (`volunteer_id`) REFERENCES `volunteers` (`id`),
  ADD CONSTRAINT `redemptions_ibfk_2` FOREIGN KEY (`reward_id`) REFERENCES `rewards` (`id`);

--
-- Constraints for table `stories`
--
ALTER TABLE `stories`
  ADD CONSTRAINT `stories_ibfk_1` FOREIGN KEY (`volunteer_id`) REFERENCES `volunteers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`volunteer_id`) REFERENCES `volunteers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `video_progress`
--
ALTER TABLE `video_progress`
  ADD CONSTRAINT `video_progress_ibfk_1` FOREIGN KEY (`volunteer_id`) REFERENCES `volunteers` (`id`),
  ADD CONSTRAINT `video_progress_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `learning_resources` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
