<?php
// Contact form handling
$contactMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contactSubmit'])) {
    $name = trim(htmlspecialchars($_POST['name']));
    $email = trim(htmlspecialchars($_POST['email']));
    $message = trim(htmlspecialchars($_POST['message']));

    // Server-side validation
    $errors = [];
    if (empty($name) || strlen($name) < 2) {
        $errors[] = 'Name must be at least 2 characters long.';
    }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid email is required.';
    }
    if (empty($message) || strlen($message) < 10) {
        $errors[] = 'Message must be at least 10 characters long.';
    }

    if (empty($errors)) {
        $to = "support@donationsystem.org";
        $subject = "New Contact Form Message";
        $body = "From: $name\nEmail: $email\n\nMessage:\n$message";
        // Prevent header injection
        $headers = "From: no-reply@donationsystem.org\r\n";
        $headers .= "Reply-To: $email\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

        if (@mail($to, $subject, $body, $headers)) {
            $contactMsg = "Your message has been sent successfully!";
        } else {
            $contactMsg = "Failed to send message. Please try again later.";
            // Log error (in a production environment, use proper logging)
            error_log("Mail failed: To: $to, From: $email, Subject: $subject");
        }
    } else {
        $contactMsg = "Errors: " . implode(" ", $errors);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome | Donation Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800&display=swap" rel="stylesheet">
  <style>
    html, body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      overflow-x: hidden;
      background: #FFF6E7; /* Light peach background from Space ECE */
      color: #000000;
      line-height: 1.6;
    }
    .hero {
      height: 100vh;
      text-align: center;
      padding-top: 150px;
      position: relative;
      overflow: hidden;
    }
    .hero::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.1);
      z-index: 1;
    }
    .logo {
      position: fixed;
      top: 20px;
      left: 30px;
      z-index: 20;
      transition: transform 0.3s ease;
    }
    .logo img {
      height: 70px; /* Increased logo size */
      filter: drop-shadow(2px 2px 4px rgba(0, 0, 0, 0.2));
    }
    .logo:hover {
      transform: scale(1.1);
    }
    .nav {
      position: fixed;
      top: 20px;
      right: 30px;
      z-index: 20;
      display: flex;
      gap: 15px;
    }
    .nav a {
      color: #FFFFFF;
      background: rgba(255, 170, 0, 0.9); /* Orange to match welcome-box */
      padding: 12px 20px;
      margin-left: 10px;
      border-radius: 5px;
      text-decoration: none;
      font-weight: 600;
      font-size: 16px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
    }
    .nav a::after {
      content: '';
      position: absolute;
      width: 0;
      height: 100%;
      top: 0;
      left: 0;
      background: rgba(255, 255, 255, 0.2);
      transition: width 0.3s ease;
    }
    .nav a:hover::after {
      width: 100%;
    }
    .nav a:hover {
      background: rgba(204, 136, 0, 0.9); /* Darker orange for hover */
      transform: translateY(-3px);
      box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
    }
    .title-box {
      background: #FFFFFF;
      color: #000000;
      padding: 15px 40px;
      display: inline-block;
      border-radius: 10px;
      font-family: 'Montserrat', sans-serif;
      font-weight: 800;
      font-size: 2rem;
      margin-bottom: 30px;
      text-transform: uppercase;
      letter-spacing: 2px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      animation: fadeIn 1s ease;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .welcome-box {
      max-width: 900px;
      margin: 0 auto;
      background: rgba(255, 170, 0, 0.9); /* Orange from Space ECE */
      border-radius: 10px;
      padding: 60px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      position: relative;
      z-index: 2;
    }
    .welcome-text h1 {
      font-family: 'Montserrat', sans-serif;
      font-weight: 800;
      font-size: 5rem;
      letter-spacing: 3px;
      color: #000000;
      text-shadow: 3px 3px 10px rgba(0, 0, 0, 0.3);
      animation: slideUp 1s ease;
    }
    @keyframes slideUp {
      from { opacity: 0; transform: translateY(50px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .welcome-text h4 {
      font-size: 1.5rem;
      color: #000000;
      margin-bottom: 20px;
    }
    .welcome-text p {
      color: #000000;
    }
    .btn-start {
      background: #27ae60; /* Green from Space ECE */
      color: #FFFFFF;
      border-radius: 5px;
      padding: 15px 35px;
      font-weight: 600;
      border: none;
      margin-top: 30px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
    }
    .btn-start:hover {
      background: #219653; /* Darker green */
      transform: translateY(-5px);
      box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
    }
    .terms {
      margin-top: 25px;
      font-size: 1rem;
      color: #000000;
    }
    .terms a {
      color: #27ae60; /* Green for links */
      text-decoration: underline;
    }
    .popup {
      display: none;
      position: fixed;
      top: 15%;
      left: 50%;
      transform: translateX(-50%);
      z-index: 9999;
      background: #FFFFFF;
      color: #000000;
      padding: 40px;
      border-radius: 10px;
      width: 90%;
      max-width: 600px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      animation: slideDown 0.6s ease;
    }
    @keyframes slideDown {
      from { top: -100px; opacity: 0; }
      to { top: 15%; opacity: 1; }
    }
    .popup h2 {
      margin-bottom: 25px;
      font-family: 'Montserrat', sans-serif;
      font-weight: 800;
      font-size: 2.5rem;
      color: #000000;
    }
    .popup .close-btn {
      position: absolute;
      top: 15px;
      right: 25px;
      font-size: 28px;
      cursor: pointer;
      color: #000000;
      transition: transform 0.3s ease;
    }
    .popup .close-btn:hover {
      transform: rotate(90deg);
    }
    .popup ul li::before {
      content: '✅';
      margin-right: 8px;
    }
    .popup ul li {
      color: #000000;
    }
    .popup .form-control {
      background: #ecf0f1; /* Light gray from Space ECE */
      border: 1px solid #ddd;
      border-radius: 5px;
      color: #000000;
      padding: 10px;
    }
    .popup .form-control:focus {
      border-color: #27ae60; /* Green border on focus */
      box-shadow: 0 0 0 0.25rem rgba(39, 174, 96, 0.25);
    }
    .popup .alert-info {
      background: #FFB347; /* Orange for messages */
      color: #000000;
      border: none;
      border-radius: 5px;
    }
    footer {
      padding: 20px;
      background: #FFFFFF;
      color: #000000;
      text-align: center;
      font-size: 0.9rem;
      box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
    }
    @media (max-width: 768px) {
      .welcome-text h1 {
        font-size: 3rem;
      }
      .welcome-box {
        padding: 30px;
      }
      .popup {
        width: 95%;
        padding: 20px;
      }
    }
  </style>
</head>
<body>

<!-- Logo -->
<div class="logo">
  <img src="uploads/image.jpg" alt="Logo">
</div>


<!-- Home Section -->
<section id="home" class="hero">
  <div class="title-box">DONATION MANAGEMENT SYSTEM</div>
  <div class="welcome-box">
    <div class="welcome-text">
      <h1>WELCOME</h1>
      <h4>to our Donation Management Community</h4>
      <p class="mt-3">A place to manage donations, donors, and community impact efficiently with cutting-edge technology.</p>
      <form method="get" action="login.php" onsubmit="return checkTerms()">
        <div class="terms">
          <input type="checkbox" id="agree" required>
          <label for="agree">
            I agree to the <a href="#" onclick="alert('Terms and Conditions: By using this platform, you agree to responsibly manage donor data, respect privacy, and comply with all applicable laws. Misuse will result in revoked access.');">Terms and Conditions</a>
          </label>
        </div>
        <button type="submit" class="btn btn-start">Join Us Now</button>
      </form>
    </div>
  </div>
</section>


<!-- Footer -->
<footer>
  Donation Management System | SpaceECE | 2025
</footer>


</body>
</html>