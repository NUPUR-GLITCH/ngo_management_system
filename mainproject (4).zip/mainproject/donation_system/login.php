<?php
session_start();
include 'db.php';

$error = '';
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = sha1($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM users WHERE username=? AND password=?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $_SESSION['admin'] = $username;
        header("Location: index.php");
        exit();
    } else {
        $error = "Invalid credentials!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Donation Management System - Admin Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800&display=swap" rel="stylesheet">
  <style>
    body {
      background: #FFF6E7; /* Light peach background from Space ECE */
      font-family: Arial, sans-serif;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0;
      position: relative;
    }
    body::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.1); /* Light overlay for contrast */
      z-index: 1;
    }
    .social-media-box {
      position: absolute;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(255, 170, 0, 0.9); /* Orange from Space ECE */
      padding: 10px 20px;
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      z-index: 3;
      text-align: center;
      display: flex;
      justify-content: center;
      gap: 15px;
    }
    .social-media-box a {
      color: #000000;
      text-decoration: none;
      font-size: 1.2rem;
      transition: color 0.3s ease;
      display: flex;
      align-items: center;
      gap: 5px;
    }
    .social-media-box a:hover {
      color: #FFFFFF;
    }
    .social-media-box svg {
      width: 24px;
      height: 24px;
      fill: #000000;
      transition: fill 0.3s ease, transform 0.3s ease;
    }
    .social-media-box a:hover svg {
      fill: #FFFFFF;
      transform: scale(1.1);
    }
    .social-media-box .youtube-icon {
      width: 32px;
      height: 32px;
      padding: 4px;
    }
    .funds-explanation-box {
      position: fixed;
      top: 50%;
      left: 20px;
      transform: translateY(-50%);
      width: 300px;
      background: rgba(255, 170, 0, 0.9); /* Orange from Space ECE */
      padding: 15px;
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      z-index: 2;
      text-align: center;
      color: #000000;
      font-size: 0.95rem;
      display: none; /* Hidden by default */
      max-height: 80vh;
      overflow-y: auto;
    }
    .toggle-button {
      margin-top: 20px;
      background-color: #27ae60; /* Green from Space ECE */
      color: #FFFFFF;
      border: none;
      border-radius: 5px;
      padding: 10px 20px;
      font-size: 1rem;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    .toggle-button:hover {
      background-color: #219653; /* Darker green on hover */
    }
    .login-container {
      width: 400px;
      padding: 2.5rem 2rem;
      background: rgba(255, 170, 0, 0.9); /* Orange from Space ECE */
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      text-align: center;
      position: relative;
      z-index: 2;
      margin-top: 60px;
    }
    .login-container h2 {
      color: #000000;
      font-family: 'Montserrat', sans-serif;
      font-weight: 800;
      margin-bottom: 1rem;
    }
    .login-container h5 {
      color: #000000;
      margin-bottom: 1.5rem;
    }
    .form-control {
      border-radius: 5px;
      border: 1px solid #ddd;
      background-color: #ecf0f1; /* Light gray from Space ECE */
      color: #000000;
    }
    .form-control:focus {
      border-color: #27ae60; /* Green border on focus */
      box-shadow: 0 0 0 0.25rem rgba(39, 174, 96, 0.25); /* Green shadow */
    }
    .btn-login {
      border-radius: 5px;
      padding: 12px 30px;
      font-size: 1.1rem;
      background-color: #27ae60; /* Green from Space ECE */
      border: none;
      color: #FFFFFF;
      transition: background-color 0.3s ease;
    }
    .btn-login:hover {
      background-color: #219653; /* Darker green on hover */
    }
    .btn-donor {
      border-radius: 5px;
      padding: 10px 20px;
      font-size: 1rem;
      background-color: #27ae60; /* Green from Space ECE */
      border: none;
      color: #FFFFFF;
      text-decoration: none;
      display: inline-block;
      margin-top: 1rem;
      transition: background-color 0.3s ease;
    }
    .btn-donor:hover {
      background-color: #219653; /* Darker green on hover */
    }
    .alert-danger {
      background-color: #FF0000; /* Red for error */
      color: #FFFFFF;
      border-radius: 5px;
      border: none;
    }
    .donation-counter {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 300px;
      background: rgba(255, 170, 0, 0.9); /* Orange from Space ECE */
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      z-index: 3;
      padding: 20px;
      text-align: center;
      color: #000000;
      transition: transform 0.3s ease;
    }
    .donation-counter:hover {
      transform: scale(1.05);
    }
    .donation-counter h4 {
      color: #000000;
      margin-bottom: 15px;
      font-family: 'Montserrat', sans-serif;
      font-weight: 800;
      text-transform: uppercase;
    }
    .donation-counter p {
      color: #000000;
      font-size: 1.3rem;
      margin: 5px 0;
      font-weight: 600;
    }
    .funds-allocation {
      margin-top: 15px;
      font-size: 0.9rem;
    }
    .funds-allocation p {
      margin: 5px 0;
      color: #000000;
    }
    .progress-bar-container {
      margin-top: 15px;
      background: rgba(255, 255, 255, 0.2);
      border-radius: 5px;
      height: 20px;
      overflow: hidden;
    }
    .progress-bar {
      height: 100%;
      background: #27ae60; /* Green from Space ECE */
      width: 0%;
      transition: width 0.5s ease;
      border-radius: 5px;
      text-align: right;
      padding-right: 10px;
      color: #FFFFFF;
      font-size: 0.9rem;
      font-weight: bold;
    }
  </style>
</head>
<body>

<div class="social-media-box">
  <a href="https://www.facebook.com/SpacECE/" aria-label="Facebook">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z"/></svg>
    SpacECE
  </a>
  <a href="https://x.com/ece_spac" aria-label="Twitter">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-.139 9.237c.209 4.617-3.234 9.765-9.33 9.765-1.854 0-3.579-.543-5.032-1.475 1.742.205 3.48-.278 4.86-1.359-1.437-.027-2.649-.976-3.066-2.28.515.098 1.021.069 1.482-.056-1.579-.317-2.668-1.739-2.633-3.26.442.246.949.394 1.486.411-1.461-.977-1.875-2.907-1.016-4.383 1.619 1.986 4.038 3.293 6.766 3.43-.479-2.053 1.08-4.03 3.199-4.03.943 0 1.797.398 2.395 1.037.748-.147 1.451-.42 2.086-.796-.246.767-.766 1.41-1.443 1.816.664-.08 1.297-.256 1.885-.517-.439.656-.996 1.234-1.639 1.697z"/></svg>
    @ece_spac
  </a>
  <a href="https://www.instagram.com/spac.ece/" aria-label="Instagram">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M14.829 6.302c-.738-.034-.96-.04-2.829-.04s-2.09.007-2.828.04c-1.899.087-2.783.986-2.87 2.87-.033.738-.041.959-.041 2.828s.008 2.09.041 2.829c.087 1.879.967 2.783 2.87 2.87.737.033.959.041 2.828.041 1.87 0 2.091-.007 2.829-.041 1.899-.086 2.782-.988 2.87-2.87.033-.738.04-.96.04-2.829s-.007-2.09-.04-2.828c-.088-1.883-.973-2.783-2.87-2.87zm-2.829 9.293c-1.985 0-3.595-1.609-3.595-3.595 0-1.985 1.61-3.594 3.595-3.594s3.595 1.609 3.595 3.594c0 1.985-1.61 3.595-3.595 3.595zm3.737-6.491c-.464 0-.84-.376-.84-.84 0-.464.376-.84.84-.84.464 0 .84.376.84.84 0 .463-.376.84-.84.84zm-1.404 2.896c0 1.289-1.045 2.333-2.333 2.333s-2.333-1.044-2.333-2.333c0-1.289 1.045-2.333 2.333-2.333s2.333 1.044 2.333 2.333zm-2.333-12c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm6.958 14.886c-.115 2.545-1.532 3.955-4.071 4.072-.747.034-.986.042-2.887.042s-2.139-.008-2.886-.042c-2.544-.117-3.955-1.529-4.072-4.072-.034-.746-.042-.985-.042-2.886 0-1.901.008-2.139.042-2.886.117-2.544 1.529-3.955 4.072-4.071.747-.035.985-.043 2.886-.043s2.14.008 2.887.043c2.545.117 3.957 1.532 4.071 4.071.034.747.042.985.042 2.886 0 1.901-.008 2.14-.042 2.886z"/></svg>
    @spac.ece
  </a>
  <a href="https://www.youtube.com/channel/UC8ZUYAoz4vsgHPWIiTCL_dA" aria-label="YouTube">
    <svg class="youtube-icon" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24"><path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm4.441 16.892c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86s.274.072.376-.043c.101-.116.433-.506.549-.68.116-.173.231-.145.39-.087s1.011.477 1.184.564.289.13.332.202c.045.072.045.419-.1.824zm-6.441-7.234l4.917 2.338-4.917 2.346v-4.684z"/></svg>
    SpacECE
  </a>
  <a href="https://wa.me/919096305648" aria-label="WhatsApp">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.77-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86s.274.072.376-.043c.101-.116.433-.506.549-.68.116-.173.231-.145.39-.087s1.011.477 1.184.564.289.13.332.202c.045.072.045.419-.1.824zm-3.423-14.416c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm.029 18.88c-1.161 0-2.305-.292-3.318-.844l-3.677.964.984-3.595c-.607-1.052-.927-2.246-.926-3.468.001-3.825 3.113-6.937 6.937-6.937 1.856.001 3.598.723 4.907 2.034 1.31 1.311 2.031 3.054 2.030 4.908-.001 3.825-3.113 6.938-6.937 6.938z"/></svg>
    WhatsApp
  </a>
</div>

<div class="funds-explanation-box" id="fundsExplanationBox">
  <p><strong>Your Donations at Work</strong></p>
  <p>Your generous contributions are making a significant impact across multiple sectors. We allocate 50% of funds to education initiatives, supporting underprivileged students with scholarships, school supplies, and digital learning tools. This has enabled over 1,000 students to continue their education in the past year alone.</p>
  <p>Another 30% goes to healthcare programs, funding medical camps, providing essential medicines, and improving rural clinic infrastructure. Last month, we assisted 500 families with free health check-ups and distributed critical supplies to remote areas.</p>
  <p>The remaining 20% is dedicated to disaster relief efforts, offering immediate aid such as food, water, and shelter during natural calamities. Recently, our team provided relief to 200 households affected by floods, ensuring their safety and recovery.</p>
  <p><strong>Our Impact</strong></p>
  <p>Every dollar you donate helps us expand these efforts. We partner with local organizations to ensure funds reach those in need efficiently. Our transparent process allows donors to see the real change their support creates, from building schools to saving lives.</p>
  <p><strong>Call to Action</strong></p>
  <p>Join us in making a difference! Log in as a donor to contribute or spread the word through our social media channels. Your support can transform communities and provide hope where it’s needed most. Together, we can achieve more!</p>
</div>

<div class="login-container">
    <h2>Donation Management System</h2>
    <h5>Admin Login</h5>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="post">
        <input type="text" name="username" class="form-control mb-3" placeholder="Username" required>
        <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
        <button type="submit" name="login" class="btn btn-login w-100">Login</button>
    </form>

    <a href="donor_login.php" class="btn-donor">Donor Login</a>
    <button class="toggle-button" onclick="toggleFundsBox()">Show Funds Info</button>
</div>

<div class="donation-counter" id="donationCounter">
  <h4>Total Donations</h4>
  <p id="donationTotal">$0.00</p>
  <p id="lastUpdated">Last updated: Loading...</p>
  <div class="funds-allocation">
    <p><strong>Where Funds Go:</strong></p>
    <p>50% Education</p>
    <p>30% Healthcare</p>
    <p>20% Disaster Relief</p>
  </div>
  <div class="progress-bar-container">
    <div class="progress-bar" id="progressBar">0%</div>
  </div>
</div>

<script>
  function updateDonationCounter() {
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        const data = JSON.parse(this.responseText);
        const total = parseFloat(data.total);
        document.getElementById('donationTotal').textContent = `$${total.toFixed(2)}`;
        document.getElementById('lastUpdated').textContent = `Last updated: ${data.timestamp}`;
        
        const goal = 10000;
        let percentage = (total / goal) * 100;
        percentage = Math.min(100, Math.max(0, percentage));
        const progressBar = document.getElementById('progressBar');
        progressBar.style.width = `${percentage}%`;
        progressBar.textContent = `${percentage.toFixed(1)}%`;
      }
    };
    xhttp.open("GET", "get_total_donations.php", true);
    xhttp.send();
  }

  function toggleFundsBox() {
    const box = document.getElementById('fundsExplanationBox');
    box.style.display = box.style.display === 'block' ? 'none' : 'block';
  }

  updateDonationCounter();
  setInterval(updateDonationCounter, 10000);
</script>

</body>
</html>